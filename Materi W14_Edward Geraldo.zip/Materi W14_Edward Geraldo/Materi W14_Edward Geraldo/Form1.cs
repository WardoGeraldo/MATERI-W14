﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Materi_W14_Edward_Geraldo
{
    public partial class mainForm : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand = new MySqlCommand();
        MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter();
        string sqlQuery;
        DataTable dt;
        DataTable dtTeamCT;
        DataTable detail;
        DataTable dtCTcoba;
        DataTable dtType; 
        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            //dt = new DataTable();
            //dt.Columns.Add("Minute");
            //dt.Columns.Add("Team");
            //dt.Columns.Add("Player");
            //dt.Columns.Add("Type");
            //sqlConnect = new MySqlConnection("server = localhost; uid = student; pwd = isbmantap; database = premier_league;");
            //sqlQuery = "select * from team";
            //sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            //sqlDataAdapter.Fill(dt);
            //cbox_team.DataSource = dt;
            //cbox_team.DisplayMember = "team_name";
            //cbox_team.ValueMember = "team_id";
            dtTeamCT = new DataTable();
            sqlConnect = new MySqlConnection("server = localhost; uid = student; pwd = isbmantap; database = premier_league;");
            sqlQuery = "select team_name, team_id from team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamCT);
            cbox_team.DataSource = dtTeamCT;
            cbox_team.DisplayMember = "team_name";
            cbox_team.ValueMember = "team_id";

            dtCTcoba = new DataTable();
            dtCTcoba.Columns.Add("Minute");
            dtCTcoba.Columns.Add("Team");
            dtCTcoba.Columns.Add("Player");
            dtCTcoba.Columns.Add("Type");



        }

        private void cbox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DataTable player = new DataTable();
            //cbox_player.SelectedItem = null;
            //sqlQuery = "select player_name from player left join team on team.team_name = '" + cbox_team.Text + "'  where player.team_id = team.team_id AND status = 1 group by player_name;";
            //sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            //sqlDataAdapter.Fill(player);
            //cbox_player.DataSource = player;
            //cbox_player.DisplayMember = "player";
            //cbox_player.ValueMember = "player_name";
            //label5.Text = cbox_team.SelectedValue.ToString(); coba aja kalau mau bandingin value member ama display

            DataTable playerCT = new DataTable();
            cbox_player.SelectedItem = null;
            sqlQuery = $"select * from player where team_id = '{cbox_team.SelectedValue}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(playerCT);
            cbox_player.DataSource = playerCT;
            cbox_player.DisplayMember = "player_name";
            cbox_player.ValueMember = "player_id";

            dtType = new DataTable();
            dtType.Columns.Add("Singkatan");
            dtType.Columns.Add("Lengkap");
            dtType.Rows.Add("GO", "Goal");
            dtType.Rows.Add("GP", "Goal Penalty");
            dtType.Rows.Add("GW", "Own Goal");
            dtType.Rows.Add("CR", "Red Card");
            dtType.Rows.Add("CY", "Yellow Card");
            dtType.Rows.Add("PM", "Penalty Miss");
            cbox_type.DataSource = dtType;
            cbox_type.DisplayMember = "Lengkap";
            cbox_type.ValueMember = "Singkatan";
        }

        private void cbox_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            //detail = new DataTable();
            //detail.Columns.Add("Minute");
            //detail.Columns.Add("Team ID");
            //detail.Columns.Add("Player ID");
            //detail.Columns.Add("Type");
            ////cbox_player.SelectedItem = null;
            //sqlQuery = $"select * from dmatch where player_id = '{cbox_player.SelectedValue}';";
            //sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            //sqlDataAdapter.Fill(detail);
            //dgv.DataSource = detail;

            //cara pak ct
            
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            dtCTcoba.Rows.Add(tb_minute.Text, cbox_team.SelectedValue,  cbox_player.SelectedValue, cbox_type.SelectedValue);
            dgv.DataSource = dtCTcoba;

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        
    }
}
